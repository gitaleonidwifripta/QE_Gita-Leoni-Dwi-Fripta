package prioritas1;

public class product {
        private String nama;
        private String deskripsi;
        private int harga;
        private int jumlahStok;

        public product(String nama, String deskripsi, int harga, int jumlahStok) {
            this.nama = nama;
            this.deskripsi = deskripsi;
            this.harga = harga;
            this.jumlahStok = jumlahStok;
        }


        // Getter methods
        public String getNama() {
            return nama;
        }

        public String getDeskripsi() {
            return deskripsi;
        }

        public int getHarga() {
            return harga;
        }

        public int getJumlahStok() {
            return jumlahStok;
        }

        // Setter methods
        public void setNama(String nama) {
            this.nama = nama;
        }

        public void setDeskripsi(String deskripsi) {
            this.deskripsi = deskripsi;
        }

        public void setHarga(int harga) {
            this.harga = harga;
        }

        public void setJumlahStok(int jumlahStok) {
            this.jumlahStok = jumlahStok;
        }

        // Method to get product information
        public void getInfo() {
            System.out.println("nama: " + nama);
            System.out.println("Deskripsi: " + deskripsi);
            System.out.println("Harga: " + harga);
            System.out.println("JumlahStok: " + jumlahStok);
        }


        public static void main(String[] args) {
            System.out.println("===");
            System.out.println("Info product");
            product p = new product("Coffe", "This is coffee", 15000, 10);
            product q = new product("Milk", "This is fresh milk", 25000, 10);
            product r = new product("Apple juice", "This is juice", 18000, 20);
            p.getInfo();
            q.getInfo();
            r.getInfo();
            System.out.println("===");
        }

}
